#!/usr/bin/env python
# -*- coding: UTF-8 -*-

"""Magic White Powder package"""

from setuptools import setup
# from codecs import open
import io
from os import path

# --- get version ---
version = "1.1"

# --- /get version ---

setup(
    name='mwp',
    version=version,
    description='Magic White Powder package',
    long_description='Magic White Powder package',
    url='https://github.com/AnnaVelDA/Reboot20',
    author='Anna Velikobratova',
    author_email='borislavanc@gmail.com',
    license='Apache',
    classifiers=[
        'License :: OSI Approved :: Apache Software License',
        'Development Status :: 3 - Alpha',
        # 'Development Status :: 4 - Beta',
        # 'Development Status :: 5 - Production/Stable',

        'Operating System :: OS Independent',
        'Intended Audience :: Developers',
        'Topic :: Office/Business :: Financial',
        'Topic :: Office/Business :: Financial :: Investment',
        
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
    platforms=['any'],
    keywords='reboot20, magic white powder project, pandas learning',
    packages=["mwp"],
    install_requires=['pandas>=0.24', 'numpy>=1.15',
                      'yfinance', 'bs4', 'matplotlib']
)
