version = "1.0"
import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt
from bs4 import BeautifulSoup

# Котировки нефти, курс eur/usd
dbc = pd.read_excel('cur_oil.xlsx')

# Затраты на производство
PRODUCTION_COST = 400 # (EUR)

# Расходы на логистику
EU_LOGISTIC_COST_EUR = 30 # в Европу в евро
CN_LOGISTIC_COST_USD = 130 # в Китай в долларах



# * Справочная информация по клиентам(объемы, локации, комментарии) 
customers = {
    'Monty':{
        'location':'EU',
        'volumes':200,
        'comment':'moving_average'
    },
    
    'Triangle':{
        'location':'CN',
        'volumes': 30,
        'comment': 'monthly'
    },
    'Stone':{
        'location':'EU',
        'volumes': 150,
        'comment': 'moving_average'
    },
    'Poly':{
        'location':'EU',
        'volumes': 70,
        'comment': 'monthly'
    }
}
# Скидки
discounts = {'up to 100': 0.01, # 1%
             'up to 300': 0.05, # 5%
             '300 plus': 0.1}   #10%


class MagicWhitePowder:
        """Формула расчета цены на продукт"""
        
        def __init__(self):
            self.PRODUCTION_COST = 400
            self.EU_LOGISTIC_COST_EUR = 30 # в Европу в евро
            self.CN_LOGISTIC_COST_USD = 130 # в Китай в долларах
        
        def logistic_cost (self, region, EUR_USD):
            assert region in ["EU", "CN"], f"Не известный регион {region}"
            if region == 'EU':
                cost = self.EU_LOGISTIC_COST_EUR
            elif  region == 'CN':
                cost = self.CN_LOGISTIC_COST_USD / EUR_USD
            return cost
        
        def fca(self, oil_price, EUR_USD):
            """Расчет цены на заводе"""
            return  16 * oil_price / EUR_USD + self.PRODUCTION_COST    
        
        def ddp(self, oil_price, EUR_USD, region):
            """Расчет цены c доставкой для клиента"""
            return self.fca(oil_price, EUR_USD) +  self.logistic_cost(region, EUR_USD)

